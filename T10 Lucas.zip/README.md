# BACK-END_T10
POO com PHP

Executar as atividades 1 e 2 propostas no Tema 10. Em seguida salvar como resposta1.php e respsota2.php, registrando num repositório no seu GitHub e preencher o formulário abaixo:

LINK PARA REGISTRO DE ENVIO E APOIOS: https://forms.gle/tsKJ4zT3nzFCnPHh7
